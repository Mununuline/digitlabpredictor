# Deploy Digit Radar

## Vercel (what you already use)
1. Unzip this folder on a computer. Open a terminal inside it (Node 18+).
2. `npx vercel` (log in, accept the defaults) then `npx vercel --prod`.
3. Vercel dashboard > your project > Settings > Environment Variables. Add:
   - `APP_PASSWORD`: long passphrase of your choice (your login to the site)
   - `DERIV_API_TOKEN`: token with Read + Trade scopes only
   - `DERIV_APP_ID`: the app / client id Deriv gave you
   - `DERIV_ACCOUNT_DEMO`: your demo account id (look it up with `curl -H "x-app-password: PASS" https://YOURSITE/api/deriv/accounts`)
   - `ANTHROPIC_API_KEY`: optional, for the analyst panel
4. Deployments > latest > Redeploy, so the settings apply.
5. Open the site > Robots > enter the password > Demo account > Connect. Read the connection log if it fails.

Leave `DERIV_ALLOW_REAL` unset until you have run a few hundred demo or paper trades and are happy with the results.

## Render / Docker / any Node host
`npm start` runs `server.js`. `render.yaml` and `Dockerfile` are included.

## Checks before real money
- Paper and demo results over several hundred trades, shown next to what luck predicts (Robots > Robot report, Journal).
- Stake is a small share of balance, max loss is a number you will not move mid-session.
- Remember: digits are random and payouts are below fair odds. No setting changes that.
