// Vercel entry point: every /api/* request runs the same handler as server.js.
module.exports = require('../server.js');
